<?php
/* *
 * 配置文件
 */

//支付接口地址
$epay_config['apiurl'] = 'http://pay.www.com/';

//商户ID
$epay_config['pid'] = '1000';

//商户密钥
$epay_config['key'] = 'WWc3Z2jkK7jhNGPALcGKjHLPK47wRK85';
